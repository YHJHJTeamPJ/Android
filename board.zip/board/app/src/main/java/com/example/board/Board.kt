package com.example.board

import java.util.*

class Board (
    val boardnumber: Long,
    val boardcontent: String,
    val boardnickname: String,
    val boardtitle: String,
    val regdate: Date
)